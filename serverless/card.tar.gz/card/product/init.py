# 进入容器后运行，或者在容器内自动运行
from app import db, Product
db.create_all()

if not Product.query.first():
    db.session.add_all([
        Product(name='商品A', price=9.9),
        Product(name='商品B', price=19.9)
    ])
    db.session.commit()


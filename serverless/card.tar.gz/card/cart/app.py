from flask import Flask, request

app = Flask(__name__)
cart = {}

@app.route('/cart/add', methods=['POST'])
def add_to_cart():
    data = request.json
    product_id = data['product_id']
    quantity = data['quantity']
    if product_id not in cart:
        cart[product_id] = {'quantity': quantity}
    else:
        cart[product_id]['quantity'] += quantity
    return {'message': 'add'}

@app.route('/cart/remove', methods=['POST'])
def remove_from_cart():
    data = request.json
    product_id = data['product_id']
    quantity = data['quantity']
    if product_id in cart:
        if cart[product_id]['quantity'] > quantity:
            cart[product_id]['quantity'] -= quantity
        else:
            del cart[product_id]
    return {'message': 'move'}

@app.route('/cart/update', methods=['POST'])
def update_cart():
    data = request.json
    product_id = data['product_id']
    quantity = data['quantity']
    if product_id in cart:
        cart[product_id]['quantity'] = quantity
    return {'message': 'update'}

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)


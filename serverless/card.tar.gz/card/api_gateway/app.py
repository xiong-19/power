from flask import Flask, request
import requests

app = Flask(__name__)

@app.route('/cart/add', methods=['POST'])
def add_cart():
    resp = requests.post('http://cart:8080/cart/add', json=request.json)
    return resp.json()


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8088)

